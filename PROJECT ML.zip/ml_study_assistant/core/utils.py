from transformers import pipeline
from keybert import KeyBERT
import pdfminer.high_level


summarizer = pipeline("summarization", model="facebook/bart-large-cnn")
kw_model = KeyBERT()

def extract_text_from_pdf(file_path):
    return pdfminer.high_level.extract_text(file_path)

def summarize_text(text):
    return summarizer(text, max_length=150, min_length=50, do_sample=False)[0]['summary_text']

def extract_keywords(text):
    return ', '.join(kw_model.extract_keywords(text, keyphrase_ngram_range=(1, 2), stop_words='english'))
