from django import template

register = template.Library()

@register.filter
def dict_get(dictionary, key):
    if isinstance(dictionary, dict):  # Ensure it's a dictionary
        return dictionary.get(key, "")
    return ""  # Return empty string if it's not a dictionary
