from django.db import models
from django.contrib.auth.models import User

class Document(models.Model):
    STATUS_CHOICES = [
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
        ('not_started', 'Not Started'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    file = models.FileField(upload_to='uploads/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(
        max_length=20, 
        choices=STATUS_CHOICES, 
        default='not_started'
    )
    summary = models.TextField(blank=True)
    keywords = models.TextField(blank=True)
    
    def __str__(self):
        return self.title
    
    @property
    def progress_status(self):
        """Human-readable progress status"""
        return dict(self.STATUS_CHOICES).get(self.status, 'Not Started')
    
    class Meta:
        ordering = ['-uploaded_at']
        verbose_name = 'Document'
        verbose_name_plural = 'Documents'

class GeneratedContent(models.Model):
    document = models.OneToOneField(
        Document,
        on_delete=models.CASCADE,
        related_name='generated_content'
    )
    summary = models.TextField()
    key_topics = models.TextField()
    quiz = models.JSONField()
    created_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)
    
    def key_topics_list(self):
        """Returns cleaned list of key topics"""
        return [topic.strip() for topic in self.key_topics.split(',') if topic.strip()]
    
    def get_quiz_questions(self):
        """Returns parsed quiz questions if available"""
        return self.quiz if isinstance(self.quiz, list) else []
    
    class Meta:
        verbose_name = 'Generated Content'
        verbose_name_plural = 'Generated Contents'
        ordering = ['-created_at']

