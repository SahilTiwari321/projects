from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.core.files.storage import default_storage
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from collections import Counter
from .forms import SignUpForm, DocumentUploadForm
from .models import Document, GeneratedContent
import google.generativeai as genai
import pdfplumber
import json
import random
import spacy
import time
from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.tokenizers import Tokenizer
from sumy.summarizers.lex_rank import LexRankSummarizer
from sklearn.feature_extraction.text import TfidfVectorizer, ENGLISH_STOP_WORDS
model = genai.GenerativeModel('gemini-1.5-flash')

# Initialize Gemini with API key
GOOGLE_API_KEY = "AIzaSyBbCQDnLuJjJhFUNC5PTgI9ZdoP3QbmJ98"
genai.configure(api_key=GOOGLE_API_KEY)
nlp = spacy.load("en_core_web_sm")

def extract_text(file_path):
    """Extract text from PDF using pdfplumber"""
    text = ""
    try:
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                extracted_text = page.extract_text()
                if extracted_text:
                    text += extracted_text + "\n"
    except Exception as e:
        print("PDF extraction failed:", e)
    return text.strip() or "No text available."

def generate_summary(text, sentences_count=3):
    """Generate summary using Google Gemini with fallback to LexRank"""
    if not text or len(text.split()) < 10:
        return "Summary unavailable. Not enough content."
    
  
    
    prompt = f"""Generate a concise {sentences_count}-sentence summary focusing on:
    - Key concepts
    - Main arguments
    - Important findings
    
    Text: {text[:15000]}"""
    
    try:
        for attempt in range(3):  # Retry mechanism
            try:
                response = model.generate_content(prompt)
                if response.text:
                    return response.text.strip()
                time.sleep(1)  # Rate limit protection
            except genai.types.BlockedPromptException:
                return "Content could not be processed"
        
        # Fallback to LexRank
        parser = PlaintextParser.from_string(text, Tokenizer("english"))
        summarizer = LexRankSummarizer()
        summary = summarizer(parser.document, sentences_count)
        return " ".join(str(sentence) for sentence in summary)
        
    except Exception as e:
        print("Summarization Error:", e)
        return "Error generating summary."

def extract_key_topics(text, max_topics=10):
    """
    Robust key topic extraction without TF-IDF conflicts
    Args:
        text: Input text to analyze
        max_topics: Maximum number of topics to return
    Returns:
        List of top topics sorted by relevance
    """
    if not text or not isinstance(text, str) or not text.strip():
        return ["No content available for analysis"]
    
    try:
        # Process text with spaCy
        doc = nlp(text)
        
        # Extract candidate phrases using three methods
        candidates = []
        
        # 1. Get noun chunks (multi-word phrases)
        candidates.extend(
            chunk.text.lower() for chunk in doc.noun_chunks
            if (len(chunk.text) > 3 and 
               not any(t.is_stop or t.is_punct for t in chunk)
        ))
        
        # 2. Get named entities
        candidates.extend(
            ent.text.lower() for ent in doc.ents
            if ent.label_ in ["PERSON", "ORG", "GPE", "PRODUCT", "EVENT"]
        )
        
        # 3. Get important verbs
        candidates.extend(
            token.lemma_.lower() for token in doc
            if (token.pos_ == 'VERB' and 
                token.dep_ in ['ROOT', 'acl'] and 
                len(token.text) > 3)
        )
        
        if not candidates:
            return ["No significant topics found"]
        
        # Simple frequency-based ranking (avoids TF-IDF issues)
        term_counts = Counter(candidates)
        
        # Get most common terms
        top_terms = [
            term for term, count in term_counts.most_common(max_topics * 2)
            if count >= 2  # Only include terms appearing at least twice
        ]
        
        # Filter and format results
        final_topics = []
        seen_terms = set()
        
        for term in top_terms:
            term_lower = term.lower()
            # Skip terms that are substrings of existing terms
            if not any(term_lower in seen for seen in seen_terms):
                final_topics.append(term.title())
                seen_terms.add(term_lower)
                
            if len(final_topics) >= max_topics:
                break
        
        return final_topics if final_topics else ["Relevant topics not found"]
        
    except Exception as e:
        print(f"Topic extraction error: {str(e)}")
        return ["Topic extraction temporarily unavailable"]


def generate_quiz(document_text):
    """Generate more meaningful fill-in-the-blank questions"""
    if not isinstance(document_text, str) or not document_text.strip():
        return []
    
    # Process text with spaCy
    doc = nlp(document_text)
    
    # Extract meaningful sentences (avoid questions from examples, definitions, etc.)
    sentences = [sent.text.strip() for sent in doc.sents 
                if 30 < len(sent.text.strip()) < 120  # Reasonable length
                and not any(token.text.lower() in ["example", "definition", "note"] 
                           for token in sent[:5])]  # Skip examples/definitions
    
    questions = []
    used_answers = set()
    
    for sentence in random.sample(sentences, min(5, len(sentences))):
        # Find important nouns/proper nouns that aren't too common
        candidates = [
            token.text for token in nlp(sentence) 
            if token.pos_ in ["NOUN", "PROPN"] 
            and not token.is_stop
            and len(token.text) > 3
            and token.text.lower() not in used_answers
        ]
        
        if not candidates:
            continue
            
        answer = random.choice(candidates)
        used_answers.add(answer.lower())
        
        # Get contextually relevant distractors from the same document
        doc_words = [
            token.text for token in doc 
            if token.pos_ in ["NOUN", "PROPN"]
            and token.text.lower() != answer.lower()
            and not token.is_stop
        ]
        
        # Use document words if available, fallback to sensible defaults
        if len(doc_words) >= 3:
            distractors = random.sample(doc_words, min(3, len(doc_words)))
        else:
            distractors = random.sample(
                ["concept", "approach", "analysis", "method", "None"], 3
            )
        
        options = [answer] + distractors
        random.shuffle(options)
        
        # Format the question more naturally
        blank_sentence = sentence.replace(answer, "_____", 1)
        
        questions.append({
            'question': blank_sentence,
            'options': options,
            'answer': answer,
            'context': sentence  # Keep original for reference
        })
    
    return questions
# Authentication Views
def signup_view(request):
    form = SignUpForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        user.set_password(user.password)
        user.save()
        login(request, user)
        return redirect('home')
    return render(request, "signup.html", {"form": form})

def login_view(request):
    form = AuthenticationForm(request, data=request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.get_user()
        login(request, user)
        return redirect('home')
    return render(request, "login.html", {"form": form})

def logout_view(request):
    logout(request)
    return redirect('login')

# Main Application Views
from django.shortcuts import render
from .models import Document 
@login_required
 # Assuming you have a Document model

def home_view(request):
    documents = Document.objects.filter(user=request.user)  # Get user-specific documents


    total_docs = documents.count()
    completed_count = documents.filter(status='completed').count()
    in_progress_count = documents.exclude(status='completed').count()

    context = {
        'documents': documents,
        'total_docs': total_docs,
        'completed_count': completed_count,
        'in_progress_count': in_progress_count
    }
    
    return render(request, 'home.html', context)


@login_required
def upload_view(request):
    form = DocumentUploadForm(request.POST or None, request.FILES or None)
    if request.method == "POST" and form.is_valid():
        try:
            doc = form.save(commit=False)
            doc.user = request.user
            doc.save()

            if doc.file:
                text = extract_text(doc.file.path)
                if text.strip():
                    GeneratedContent.objects.create(
                        document=doc,
                        summary=generate_summary(text),
                        key_topics=", ".join(extract_key_topics(text)),
                        quiz=json.dumps(generate_quiz(text))
                    )
            return redirect('home')
        except Exception as e:
            print("Error processing document:", e)
            form.add_error(None, "Error processing document. Please try again.")
    
    return render(request, "upload.html", {"form": form})

@login_required
def document_detail_view(request, doc_id):
    document = get_object_or_404(Document, id=doc_id, user=request.user)
    content = GeneratedContent.objects.filter(document=document).first()
    
    if not content:
        content = GeneratedContent.objects.create(
            document=document,
            summary="Processing...",
            key_topics="",
            quiz="[]"
        )
    
    return render(request, "document_detail.html", {
        "document": document,
        "content": content,
        "quiz_questions": json.loads(content.quiz) if content.quiz else [],
        "key_topics": content.key_topics.split(", ") if content.key_topics else []
    })

@login_required
def quiz_view(request, doc_id):
    document = get_object_or_404(Document, id=doc_id, user=request.user)
    content = GeneratedContent.objects.get(document=document)
    return render(request, "quiz.html", {
        "questions": json.loads(content.quiz) if content.quiz else [],
        "document": document
    })

@login_required
def progress_view(request, doc_id):
    document = get_object_or_404(Document, id=doc_id, user=request.user)
    content = GeneratedContent.objects.get(document=document)
    return render(request, "progress.html", {
        "document": document,
        "content": content,
        "key_topics": content.key_topics.split(", ") if content.key_topics else [],
        "quiz_questions": json.loads(content.quiz) if content.quiz else []
    })

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Document  # Make sure to import your Document model

@login_required
def profile_view(request):
    # Get the logged-in user
    current_user = request.user
    
    # Calculate document counts
    total_docs = Document.objects.filter(user=current_user).count()
    completed_count = Document.objects.filter(user=current_user, status='completed').count()
    in_progress_count = Document.objects.filter(user=current_user, status='in_progress').count()
    
    context = {
        'user': current_user,  # Pass the user to template as 'user'
        'total_docs': total_docs,
        'completed_count': completed_count,
        'in_progress_count': in_progress_count,
    }
    return render(request, 'profile.html', context)

# API View
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def api_upload_document(request):
    if not request.FILES:
        return Response({'error': 'No file provided'}, status=400)
    
    file = request.FILES.get('file')
    if not file:
        return Response({'error': 'Invalid file upload'}, status=400)

    try:
        file_path = default_storage.save(f"uploads/{file.name}", file)
        text = extract_text(file_path)
        
        if not text.strip():
            return Response({'error': 'No extractable text found'}, status=400)
        
        summary = generate_summary(text)
        keywords = extract_key_topics(text)
        quiz = generate_quiz(text)

        doc = Document.objects.create(
            user=request.user,
            file=file_path,
            original_filename=file.name
        )

        GeneratedContent.objects.create(
            document=doc,
            summary=summary,
            key_topics=", ".join(keywords),
            quiz=json.dumps(quiz)
        )

        return Response({
            'document_id': doc.id,
            'summary': summary,
            'keywords': keywords,
            'quiz': quiz,
            'status': 'success'
        })
        
    except Exception as e:
        return Response({
            'error': str(e),
            'status': 'error'
        }, status=500)
    

@login_required
def update_document_status(request, doc_id):
    document = get_object_or_404(Document, id=doc_id, user=request.user)
    if request.method == 'POST':
        new_status = request.POST.get('status')
        if new_status in dict(Document.STATUS_CHOICES).keys():
            document.status = new_status
            document.save()
            return JsonResponse({'status': 'success'})
    return JsonResponse({'status': 'error'}, status=400)

from django.shortcuts import redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
@login_required
def mark_completed_view(request, doc_id):
    """Mark a document's progress as completed and redirect to home."""
    document = get_object_or_404(Document, id=doc_id, user=request.user)
    if request.method == "POST":
        document.status = "completed"
        document.save()
        return redirect('home')  # Changed from JsonResponse to redirect
    return redirect('document_detail', doc_id=doc_id)
from django.http import JsonResponse
from .models import Document  

def filter_documents(request):
    status = request.GET.get('status', 'all')
    
    if status == 'all':
        documents = Document.objects.all()
    else:
        documents = Document.objects.filter(status=status)

    doc_list = [
        {
            'id': doc.id,
            'title': doc.title,
            'filename': doc.file.name.split('/')[-1],
            'status': doc.status
        } for doc in documents
    ]

    return JsonResponse({'documents': doc_list})
