from django.urls import path
from .views import (
    signup_view, login_view, logout_view, home_view, 
    upload_view, document_detail_view, quiz_view, 
    profile_view, progress_view,update_document_status,mark_completed_view,filter_documents
)

try:
    from .views import upload_document  
except ImportError:
    from .views import api_upload_document as upload_document  

urlpatterns = [
    path("", home_view, name="home"),
    path("signup/", signup_view, name="signup"),
    path("login/", login_view, name="login"),
    path("logout/", logout_view, name="logout"),
    path("upload/", upload_view, name="upload"),  
    path("document/<int:doc_id>/", document_detail_view, name="document_detail"),
    path("quiz/<int:doc_id>/", quiz_view, name="quiz"),
    path("profile/", profile_view, name="profile"),
    path("progress/<int:doc_id>/", progress_view, name="progress"),
    path('document/<int:doc_id>/update-status/', update_document_status, name='update_document_status'),
    path('progress/<int:doc_id>/completed/', mark_completed_view, name='mark_completed'),
    path("document/<int:doc_id>/update-status/", update_document_status, name="update_document_status"),
    path('documents/filter/', filter_documents, name='filter_documents'),
]


